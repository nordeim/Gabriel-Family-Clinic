/**
 * Spacing System for Gabriel Family Clinic
 * 4px base unit with accessibility-focused spacing
 */

export const spacing = {
  // Base spacing scale (4px base unit)
  scale: {
    0: "0",
    px: "1px",
    0.5: "0.125rem", // 2px
    1: "0.25rem", // 4px
    1.5: "0.375rem", // 6px
    2: "0.5rem", // 8px
    2.5: "0.625rem", // 10px
    3: "0.75rem", // 12px
    3.5: "0.875rem", // 14px
    4: "1rem", // 16px
    5: "1.25rem", // 20px
    6: "1.5rem", // 24px
    7: "1.75rem", // 28px
    8: "2rem", // 32px
    9: "2.25rem", // 36px
    10: "2.5rem", // 40px
    11: "2.75rem", // 44px - Minimum touch target
    12: "3rem", // 48px
    14: "3.5rem", // 56px
    16: "4rem", // 64px
    20: "5rem", // 80px
    24: "6rem", // 96px
    28: "7rem", // 112px
    32: "8rem", // 128px
    36: "9rem", // 144px
    40: "10rem", // 160px
    44: "11rem", // 176px
    48: "12rem", // 192px
    52: "13rem", // 208px
    56: "14rem", // 224px
    60: "15rem", // 240px
    64: "16rem", // 256px
    72: "18rem", // 288px
    80: "20rem", // 320px
    96: "24rem", // 384px
  },

  // Container widths
  container: {
    xs: "20rem", // 320px
    sm: "24rem", // 384px
    md: "28rem", // 448px
    lg: "32rem", // 512px
    xl: "36rem", // 576px
    "2xl": "42rem", // 672px
    "3xl": "48rem", // 768px
    "4xl": "56rem", // 896px
    "5xl": "64rem", // 1024px
    "6xl": "72rem", // 1152px
    "7xl": "80rem", // 1280px
    full: "100%",
    min: "min-content",
    max: "max-content",
    fit: "fit-content",
  },

  // Breakpoints for responsive design
  breakpoints: {
    xs: "320px",
    sm: "640px",
    md: "768px",
    lg: "1024px",
    xl: "1280px",
    "2xl": "1536px",
  },

  // Grid system
  grid: {
    cols: {
      1: "repeat(1, minmax(0, 1fr))",
      2: "repeat(2, minmax(0, 1fr))",
      3: "repeat(3, minmax(0, 1fr))",
      4: "repeat(4, minmax(0, 1fr))",
      6: "repeat(6, minmax(0, 1fr))",
      12: "repeat(12, minmax(0, 1fr))",
    },
    gap: {
      xs: "0.5rem", // 8px
      sm: "1rem", // 16px
      md: "1.5rem", // 24px
      lg: "2rem", // 32px
      xl: "3rem", // 48px
    },
  },

  // Accessibility-specific spacing
  accessibility: {
    // Minimum touch target size (WCAG 2.5.5 Level AAA)
    minTouchTarget: "2.75rem", // 44px
    recommendedTouchTarget: "3rem", // 48px
    largeTouchTarget: "3.5rem", // 56px

    // Spacing between interactive elements
    minInteractiveSpacing: "0.5rem", // 8px
    recommendedInteractiveSpacing: "1rem", // 16px

    // Focus indicator offset
    focusOutlineOffset: "0.125rem", // 2px
    focusOutlineWidth: "0.1875rem", // 3px

    // Content spacing for readability
    paragraphSpacing: "1.5rem", // 24px
    sectionSpacing: "3rem", // 48px
    componentSpacing: "2rem", // 32px
  },

  // Semantic spacing tokens
  semantic: {
    // Component internal spacing
    componentPaddingXs: "0.5rem", // 8px
    componentPaddingSm: "0.75rem", // 12px
    componentPaddingMd: "1rem", // 16px
    componentPaddingLg: "1.5rem", // 24px
    componentPaddingXl: "2rem", // 32px

    // Component gaps
    componentGapXs: "0.25rem", // 4px
    componentGapSm: "0.5rem", // 8px
    componentGapMd: "1rem", // 16px
    componentGapLg: "1.5rem", // 24px

    // Layout spacing
    layoutGapXs: "1rem", // 16px
    layoutGapSm: "1.5rem", // 24px
    layoutGapMd: "2rem", // 32px
    layoutGapLg: "3rem", // 48px
    layoutGapXl: "4rem", // 64px

    // Page margins
    pageMarginXs: "1rem", // 16px
    pageMarginSm: "1.5rem", // 24px
    pageMarginMd: "2rem", // 32px
    pageMarginLg: "3rem", // 48px
    pageMarginXl: "4rem", // 64px
  },
} as const;

/**
 * Spacing utilities for consistent layout
 */
export const spacingUtils = {
  // Calculate responsive spacing
  responsiveSpacing: (base: number, multiplier: number = 1.5): Record<string, string> => ({
    base: `${base}px`,
    sm: `${base * multiplier}px`,
    md: `${base * multiplier * 1.5}px`,
    lg: `${base * multiplier * 2}px`,
    xl: `${base * multiplier * 2.5}px`,
  }),

  // Stack spacing utilities
  stack: {
    tight: spacing.scale[2], // 8px
    normal: spacing.scale[4], // 16px
    relaxed: spacing.scale[6], // 24px
    loose: spacing.scale[8], // 32px
  },

  // Inline spacing utilities
  inline: {
    tight: spacing.scale[1], // 4px
    normal: spacing.scale[2], // 8px
    relaxed: spacing.scale[4], // 16px
    loose: spacing.scale[6], // 24px
  },
} as const;

export type Spacing = typeof spacing;
export type SpacingScale = keyof typeof spacing.scale;
