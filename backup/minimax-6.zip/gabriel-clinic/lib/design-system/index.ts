/**
 * Design System for Gabriel Family Clinic
 * Complete design token system with elder-friendly, WCAG AAA compliant specifications
 */

export * from "./colors";
export * from "./typography";
export * from "./spacing";
export * from "./accessibility";
export * from "./animation";
export * from "./tokens";

// Re-export main token objects for convenience
export { colors, colorUtils } from "./colors";
export { typography, typographyUtils } from "./typography";
export { spacing, spacingUtils } from "./spacing";
export { accessibility, a11yUtils } from "./accessibility";
export { animation, animationUtils, motionVariants } from "./animation";
export { designTokens, designTokenUtils } from "./tokens";

/**
 * Design system version and metadata
 */
export const designSystem = {
  version: "2.0.0",
  name: "Gabriel Family Clinic Design System",
  description: "Elder-friendly, WCAG AAA compliant design system for healthcare",
  lastUpdated: "2025-11-05",
  
  features: [
    "WCAG AAA color contrast (7:1 ratio)",
    "Modern warm teal and coral color palette",
    "Google Fonts integration (Playfair Display, Inter, Quicksand)",
    "18px base font size for elder-friendly reading",
    "Professional animation curves and easing",
    "Enhanced shadow system with depth layering",
    "Modern border radius design language",
    "44px minimum touch targets",
    "Reduced motion support",
    "High contrast mode",
    "Screen reader optimized",
    "Keyboard navigation support",
  ],

  breakpoints: {
    xs: "320px",
    sm: "640px",
    md: "768px",
    lg: "1024px",
    xl: "1280px",
    "2xl": "1536px",
  },

  tokens: {
    colors: "lib/design-system/colors.ts",
    typography: "lib/design-system/typography.ts",
    spacing: "lib/design-system/spacing.ts",
    accessibility: "lib/design-system/accessibility.ts",
    animation: "lib/design-system/animation.ts",
    enhancedTokens: "lib/design-system/tokens.ts",
  },
} as const;

export type DesignSystem = typeof designSystem;
