/**
 * Enhanced Design Tokens for Gabriel Family Clinic
 * Shadow system, border radius, and additional design foundations
 */

export const designTokens = {
  // Shadow System - Soft, layered shadows for depth
  shadow: {
    sm: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
    base: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
    md: "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
    lg: "0 20px 25px -5px rgba(0, 0, 0, 0.1)",
    xl: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
    "2xl": "0 50px 100px -20px rgba(0, 0, 0, 0.25)",
    inner: "inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)",
    
    // Colored shadows for brand elements
    colored: "0 8px 30px rgba(8, 145, 178, 0.12)", // Teal colored shadow
    "colored-lg": "0 20px 40px rgba(8, 145, 178, 0.15)",
    
    // Floating shadows for cards
    floating: "0 4px 20px rgba(0, 0, 0, 0.08)",
    "floating-lg": "0 8px 30px rgba(0, 0, 0, 0.12)",
    
    // Elder-friendly (softer, less dramatic)
    gentle: "0 2px 8px rgba(0, 0, 0, 0.06)",
    "gentle-lg": "0 4px 16px rgba(0, 0, 0, 0.08)",
  },

  // Border Radius - Modern, rounded design language
  borderRadius: {
    none: "0",
    sm: "0.125rem",   // 2px
    base: "0.25rem",  // 4px
    md: "0.375rem",   // 6px
    lg: "0.5rem",     // 8px
    xl: "0.75rem",    // 12px
    "2xl": "1rem",    // 16px
    "3xl": "1.5rem",  // 24px
    "4xl": "2rem",    // 32px
    full: "9999px",   // Perfect circles
    
    // Semantic radius values
    button: "0.5rem",        // Standard button rounding
    "button-lg": "0.75rem",   // Large button rounding
    card: "0.75rem",         // Card component rounding
    "card-lg": "1rem",       // Large card rounding
    input: "0.5rem",         // Input field rounding
    modal: "1rem",           // Modal dialog rounding
  },

  // Enhanced spacing scale (complement to spacing.ts)
  spacing: {
    0.5: "0.125rem",   // 2px
    1: "0.25rem",      // 4px
    2: "0.5rem",       // 8px
    3: "0.75rem",      // 12px
    4: "1rem",         // 16px
    6: "1.5rem",       // 24px
    8: "2rem",         // 32px
    12: "3rem",        // 48px
    16: "4rem",        // 64px
    20: "5rem",        // 80px
  },

  // Professional animation curves (complement to animation.ts)
  easing: {
    "ease-out-expo": "cubic-bezier(0.16, 1, 0.3, 1)",
    "ease-out-back": "cubic-bezier(0.34, 1.56, 0.64, 1)",
    "ease-in-out-smooth": "cubic-bezier(0.4, 0, 0.2, 1)",
    "spring-bounce": "cubic-bezier(0.68, -0.55, 0.265, 1.55)",
  },

  // Glass morphism effects
  glass: {
    light: "rgba(255, 255, 255, 0.7)",
    medium: "rgba(255, 255, 255, 0.5)",
    dark: "rgba(255, 255, 255, 0.3)",
    subtle: "rgba(255, 255, 255, 0.1)",
  },

  // Gradient definitions
  gradients: {
    primary: "linear-gradient(135deg, #0891B2 0%, #0E7490 100%)",
    "primary-soft": "linear-gradient(135deg, #F0FDFA 0%, #E0F7FA 100%)",
    accent: "linear-gradient(135deg, #FF6B6B 0%, #FF4757 100%)",
    "accent-soft": "linear-gradient(135deg, #FFE5E5 0%, #FFCCCC 100%)",
    hero: "linear-gradient(135deg, #F0FDFA 0%, rgba(255, 107, 107, 0.05) 40%, #FAFAF9 100%)",
  },

  // Focus ring styles
  focusRing: {
    default: "0 0 0 3px rgba(8, 145, 178, 0.1)",
    strong: "0 0 0 4px rgba(8, 145, 178, 0.2)",
    subtle: "0 0 0 2px rgba(8, 145, 178, 0.1)",
  },

  // Z-index scale
  zIndex: {
    hide: -1,
    auto: "auto",
    base: 0,
    docked: 10,
    dropdown: 1000,
    sticky: 1100,
    banner: 1200,
    overlay: 1300,
    modal: 1400,
    popover: 1500,
    skipLink: 1600,
    toast: 1700,
    tooltip: 1800,
  },
} as const;

/**
 * Design token utilities
 */
export const designTokenUtils = {
  // Create CSS custom property string
  toCSSVariable: (prefix: string, key: string, value: string): string => {
    return `--${prefix}-${key}: ${value};`;
  },

  // Generate CSS custom properties object
  toCSSVariables: (tokens: Record<string, any>, prefix: string = ""): Record<string, string> => {
    const vars: Record<string, string> = {};
    
    Object.entries(tokens).forEach(([key, value]) => {
      if (typeof value === "object" && value !== null) {
        Object.assign(vars, designTokenUtils.toCSSVariables(value, `${prefix}-${key}`));
      } else {
        vars[`--${prefix}-${key}`] = value;
      }
    });
    
    return vars;
  },

  // Get accessible shadow variants
  getAccessibleShadows: () => ({
    default: designTokens.shadow.base,
    hover: designTokens.shadow.lg,
    focus: designTokens.shadow.sm,
    disabled: "none",
  }),

  // Get semantic border radius
  getSemanticRadius: (component: 'button' | 'input' | 'card' | 'modal' | 'base') => {
    const radiusMap = {
      button: designTokens.borderRadius.button,
      input: designTokens.borderRadius.input,
      card: designTokens.borderRadius.card,
      modal: designTokens.borderRadius.modal,
      base: designTokens.borderRadius.base,
    };
    
    return radiusMap[component] || designTokens.borderRadius.base;
  },
} as const;

export type DesignTokens = typeof designTokens;
export type ShadowKey = keyof typeof designTokens.shadow;
export type BorderRadiusKey = keyof typeof designTokens.borderRadius;
