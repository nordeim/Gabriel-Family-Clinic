/**
 * Google Analytics 4 Configuration
 * Healthcare-specific tracking with privacy compliance
 */

export const GA_MEASUREMENT_ID = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID || '';

// Initialize Google Analytics
export const pageview = (url: string) => {
  if (typeof window.gtag !== 'undefined') {
    window.gtag('config', GA_MEASUREMENT_ID, {
      page_path: url,
      anonymize_ip: true, // HIPAA compliance
      cookie_flags: 'SameSite=None;Secure',
    });
  }
};

// Track custom events for elderly user interactions
export const event = ({
  action,
  category,
  label,
  value,
}: {
  action: string;
  category: string;
  label?: string;
  value?: number;
}) => {
  if (typeof window.gtag !== 'undefined') {
    window.gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
};

// Healthcare-specific event tracking
export const trackTextSizeChange = (size: 'normal' | 'large' | 'extra-large') => {
  event({
    action: 'text_size_change',
    category: 'accessibility',
    label: size,
  });
};

export const trackAppointmentClick = (location: string) => {
  event({
    action: 'appointment_click',
    category: 'conversion',
    label: location,
  });
};

export const trackPhoneClick = (number: string) => {
  event({
    action: 'phone_click',
    category: 'conversion',
    label: number,
  });
};

export const trackEmergencyClick = () => {
  event({
    action: 'emergency_click',
    category: 'urgent_care',
    label: 'emergency_number',
  });
};

export const trackServiceClick = (service: string) => {
  event({
    action: 'service_click',
    category: 'engagement',
    label: service,
  });
};

export const trackTestimonialView = (testimonialId: string) => {
  event({
    action: 'testimonial_view',
    category: 'engagement',
    label: testimonialId,
  });
};

export const trackLocationClick = (location: string) => {
  event({
    action: 'location_click',
    category: 'engagement',
    label: location,
  });
};

// Scroll depth tracking for elderly users
export const trackScrollDepth = (depth: number) => {
  event({
    action: 'scroll_depth',
    category: 'engagement',
    label: `${depth}%`,
    value: depth,
  });
};

// Form interaction tracking
export const trackFormStart = (formName: string) => {
  event({
    action: 'form_start',
    category: 'form_interaction',
    label: formName,
  });
};

export const trackFormSubmit = (formName: string) => {
  event({
    action: 'form_submit',
    category: 'conversion',
    label: formName,
  });
};

// Error tracking
export const trackError = (errorMessage: string, errorLocation: string) => {
  event({
    action: 'error',
    category: 'technical',
    label: `${errorLocation}: ${errorMessage}`,
  });
};

// Extend window type for gtag
declare global {
  interface Window {
    gtag: (
      command: 'config' | 'event' | 'js' | 'set',
      targetId: string,
      config?: Record<string, unknown>
    ) => void;
  }
}
