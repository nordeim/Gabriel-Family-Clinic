/**
 * Web Vitals Monitoring for Performance Tracking
 * Tracks Core Web Vitals: LCP, INP, CLS, FCP, TTFB
 */

import { onCLS, onINP, onFCP, onLCP, onTTFB, type Metric } from 'web-vitals';

// Track vitals to analytics
export function sendToAnalytics(metric: Metric) {
  // Send to Google Analytics
  if (typeof window.gtag !== 'undefined') {
    window.gtag('event', metric.name, {
      value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
      event_category: 'Web Vitals',
      event_label: metric.id,
      non_interaction: true,
    });
  }

  // Log to console in development
  if (process.env.NODE_ENV === 'development') {
    console.log(`[Web Vitals] ${metric.name}:`, {
      value: metric.value,
      rating: getVitalRating(metric),
      id: metric.id,
    });
  }
}

// Get rating for each vital
function getVitalRating(metric: Metric): 'good' | 'needs-improvement' | 'poor' {
  const thresholds: Record<string, { good: number; poor: number }> = {
    LCP: { good: 2500, poor: 4000 },
    INP: { good: 200, poor: 500 }, // Replaced FID
    CLS: { good: 0.1, poor: 0.25 },
    FCP: { good: 1800, poor: 3000 },
    TTFB: { good: 800, poor: 1800 },
  };

  const threshold = thresholds[metric.name];
  if (!threshold) return 'good';

  if (metric.value <= threshold.good) return 'good';
  if (metric.value <= threshold.poor) return 'needs-improvement';
  return 'poor';
}

// Initialize all Web Vitals tracking
export function initWebVitals() {
  onCLS(sendToAnalytics);
  onINP(sendToAnalytics); // Replaced FID with INP
  onFCP(sendToAnalytics);
  onLCP(sendToAnalytics);
  onTTFB(sendToAnalytics);
}

// Performance budget thresholds (in milliseconds unless otherwise noted)
export const PERFORMANCE_BUDGET = {
  // Core Web Vitals
  LCP: 2500, // Largest Contentful Paint - target <2.5s
  INP: 200, // Interaction to Next Paint - target <200ms (replaced FID)
  CLS: 0.1, // Cumulative Layout Shift - target <0.1
  FCP: 1800, // First Contentful Paint - target <1.8s
  TTFB: 800, // Time to First Byte - target <800ms

  // Additional metrics
  TTI: 3800, // Time to Interactive - target <3.8s
  TBT: 200, // Total Blocking Time - target <200ms
  SI: 3400, // Speed Index - target <3.4s

  // Bundle sizes (in KB)
  JS_BUNDLE: 300, // JavaScript bundle - target <300KB
  CSS_BUNDLE: 50, // CSS bundle - target <50KB
  TOTAL_PAGE_SIZE: 1500, // Total page size - target <1.5MB
} as const;

// Check if performance meets budget
export function checkPerformanceBudget(metric: Metric): boolean {
  const budget = PERFORMANCE_BUDGET[metric.name as keyof typeof PERFORMANCE_BUDGET];
  if (!budget) return true;
  return metric.value <= budget;
}

// Report performance issues
export function reportPerformanceIssue(metric: Metric) {
  if (!checkPerformanceBudget(metric)) {
    console.warn(`[Performance Budget Exceeded] ${metric.name}:`, {
      actual: metric.value,
      budget: PERFORMANCE_BUDGET[metric.name as keyof typeof PERFORMANCE_BUDGET],
      exceeded: metric.value - (PERFORMANCE_BUDGET[metric.name as keyof typeof PERFORMANCE_BUDGET] || 0),
    });

    // Send to error tracking in production
    if (process.env.NODE_ENV === 'production' && typeof window.gtag !== 'undefined') {
      window.gtag('event', 'performance_budget_exceeded', {
        event_category: 'Performance',
        event_label: metric.name,
        value: Math.round(metric.value),
      });
    }
  }
}

// Extend window type for gtag
declare global {
  interface Window {
    gtag: (
      command: 'config' | 'event' | 'js' | 'set',
      targetId: string,
      config?: Record<string, unknown>
    ) => void;
  }
}
