/**
 * Animation and Interaction Tokens for Gabriel Family Clinic
 * Elder-friendly animations with reduced motion support
 */

export const animation = {
  // Duration tokens (slower than typical for elder-friendly experience)
  duration: {
    instant: "0ms",
    fast: "200ms",
    normal: "400ms", // Slower than typical 300ms
    slow: "600ms",
    slower: "800ms",
    slowest: "1000ms",
  },

  // Easing functions - Professional transition curves
  easing: {
    // Standard easing
    linear: "linear",
    easeIn: "cubic-bezier(0.4, 0, 1, 1)",
    easeOut: "cubic-bezier(0, 0, 0.2, 1)",
    easeInOut: "cubic-bezier(0.4, 0, 0.2, 1)",

    // Professional transition curves
    "ease-out-expo": "cubic-bezier(0.16, 1, 0.3, 1)",
    "ease-out-back": "cubic-bezier(0.34, 1.56, 0.64, 1)",
    "ease-in-out-smooth": "cubic-bezier(0.4, 0, 0.2, 1)",
    "spring-bounce": "cubic-bezier(0.68, -0.55, 0.265, 1.55)",

    // Custom easing for smooth, gentle animations
    gentle: "cubic-bezier(0.25, 0.1, 0.25, 1)",
    smooth: "cubic-bezier(0.4, 0, 0.2, 1)",
    bounce: "cubic-bezier(0.68, -0.55, 0.265, 1.55)",

    // Elder-friendly (very smooth, no jarring movements)
    elderFriendly: "cubic-bezier(0.3, 0, 0.2, 1)",
  },

  // Transition properties
  transition: {
    // Common transitions
    all: {
      property: "all",
      duration: "400ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    colors: {
      property: "color, background-color, border-color",
      duration: "300ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    opacity: {
      property: "opacity",
      duration: "300ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    transform: {
      property: "transform",
      duration: "400ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    shadow: {
      property: "box-shadow",
      duration: "300ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
  },

  // Hover states (slower for elder-friendly interaction)
  hover: {
    scale: "1.02", // Subtle scale
    duration: "300ms",
    timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    opacity: "0.9",
  },

  // Focus states
  focus: {
    duration: "200ms",
    timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    scale: "1.01",
  },

  // Active states
  active: {
    scale: "0.98",
    duration: "100ms",
    timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
  },

  // Fade animations
  fade: {
    in: {
      from: { opacity: 0 },
      to: { opacity: 1 },
      duration: "400ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    out: {
      from: { opacity: 1 },
      to: { opacity: 0 },
      duration: "300ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
  },

  // Slide animations
  slide: {
    inFromTop: {
      from: { transform: "translateY(-100%)", opacity: 0 },
      to: { transform: "translateY(0)", opacity: 1 },
      duration: "500ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    inFromBottom: {
      from: { transform: "translateY(100%)", opacity: 0 },
      to: { transform: "translateY(0)", opacity: 1 },
      duration: "500ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    inFromLeft: {
      from: { transform: "translateX(-100%)", opacity: 0 },
      to: { transform: "translateX(0)", opacity: 1 },
      duration: "500ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    inFromRight: {
      from: { transform: "translateX(100%)", opacity: 0 },
      to: { transform: "translateX(0)", opacity: 1 },
      duration: "500ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
  },

  // Scale animations
  scale: {
    in: {
      from: { transform: "scale(0.9)", opacity: 0 },
      to: { transform: "scale(1)", opacity: 1 },
      duration: "400ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
    out: {
      from: { transform: "scale(1)", opacity: 1 },
      to: { transform: "scale(0.9)", opacity: 0 },
      duration: "300ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },
  },

  // Skeleton loading animations
  skeleton: {
    pulse: {
      duration: "2000ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.6, 1)",
      iterationCount: "infinite",
      keyframes: {
        "0%, 100%": { opacity: 1 },
        "50%": { opacity: 0.5 },
      },
    },
    shimmer: {
      duration: "2000ms",
      timingFunction: "linear",
      iterationCount: "infinite",
      keyframes: {
        "0%": { backgroundPosition: "-1000px 0" },
        "100%": { backgroundPosition: "1000px 0" },
      },
    },
  },

  // Modal/Dialog animations
  modal: {
    overlay: {
      in: {
        from: { opacity: 0 },
        to: { opacity: 1 },
        duration: "300ms",
        timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
      },
      out: {
        from: { opacity: 1 },
        to: { opacity: 0 },
        duration: "200ms",
        timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
      },
    },
    content: {
      in: {
        from: { transform: "scale(0.95) translateY(-20px)", opacity: 0 },
        to: { transform: "scale(1) translateY(0)", opacity: 1 },
        duration: "400ms",
        timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
      },
      out: {
        from: { transform: "scale(1) translateY(0)", opacity: 1 },
        to: { transform: "scale(0.95) translateY(-20px)", opacity: 0 },
        duration: "300ms",
        timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
      },
    },
  },

  // Reduced motion alternatives
  reducedMotion: {
    duration: "0.01ms", // Near instant
    timingFunction: "linear",
    transitionProperty: "color, background-color, border-color, opacity",
    // No transform, scale, or movement animations
  },
} as const;

/**
 * Animation utilities
 */
export const animationUtils = {
  // Create CSS transition string
  createTransition: (
    property: string,
    duration: string,
    timingFunction: string,
    delay: string = "0ms"
  ): string => {
    return `${property} ${duration} ${timingFunction} ${delay}`;
  },

  // Multiple property transitions
  createTransitions: (
    transitions: Array<{
      property: string;
      duration?: string;
      timingFunction?: string;
      delay?: string;
    }>
  ): string => {
    return transitions
      .map((t) =>
        animationUtils.createTransition(
          t.property,
          t.duration || animation.duration.normal,
          t.timingFunction || animation.easing.smooth,
          t.delay || "0ms"
        )
      )
      .join(", ");
  },

  // Check if user prefers reduced motion
  prefersReducedMotion: (): boolean => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  },

  // Get safe animation duration (respects reduced motion preference)
  getSafeDuration: (normalDuration: string): string => {
    return animationUtils.prefersReducedMotion() ? "0.01ms" : normalDuration;
  },

  // Elder-friendly animation guidelines
  elderFriendlyGuidelines: {
    // Avoid rapid flashing (seizure risk)
    maxFlashRate: 3, // flashes per second
    // Longer durations for comprehension
    minDuration: 300, // ms
    recommendedDuration: 400, // ms
    // Smooth, predictable movements
    preferredEasing: animation.easing.elderFriendly,
    // Clear start and end states
    maintainStateBetweenAnimations: true,
  },
} as const;

/**
 * Framer Motion variants for common animations
 */
export const motionVariants = {
  fadeIn: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 },
    transition: {
      duration: 0.4,
      ease: [0.4, 0, 0.2, 1],
    },
  },

  slideInFromBottom: {
    initial: { y: 50, opacity: 0 },
    animate: { y: 0, opacity: 1 },
    exit: { y: 50, opacity: 0 },
    transition: {
      duration: 0.5,
      ease: [0.4, 0, 0.2, 1],
    },
  },

  scaleIn: {
    initial: { scale: 0.9, opacity: 0 },
    animate: { scale: 1, opacity: 1 },
    exit: { scale: 0.9, opacity: 0 },
    transition: {
      duration: 0.4,
      ease: [0.4, 0, 0.2, 1],
    },
  },

  staggerContainer: {
    animate: {
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.1,
      },
    },
  },

  staggerItem: {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: {
      duration: 0.5,
      ease: [0.4, 0, 0.2, 1],
    },
  },
} as const;

export type Animation = typeof animation;
export type MotionVariant = keyof typeof motionVariants;
