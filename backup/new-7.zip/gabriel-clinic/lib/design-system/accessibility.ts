/**
 * Accessibility Tokens for Gabriel Family Clinic
 * WCAG AAA compliant accessibility system
 */

import { colors } from "./colors";

export const accessibility = {
  // Focus indicators (WCAG 2.4.7 Level AA, enhanced for AAA)
  focus: {
    ringColor: colors.primary[500],
    ringWidth: "3px",
    ringStyle: "solid",
    ringOffset: "2px",
    ringOffsetColor: colors.background.primary,
    outlineStyle: "none", // Use ring instead of outline

    // Alternative focus styles
    highContrast: {
      ringColor: colors.text.primary,
      ringWidth: "3px",
      ringStyle: "solid",
      ringOffset: "2px",
    },

    // Focus within (for containers)
    within: {
      ringColor: colors.primary[300],
      ringWidth: "2px",
      ringStyle: "solid",
      ringOffset: "4px",
    },
  },

  // Color contrast ratios (WCAG Level AAA - 7:1 for normal text, 4.5:1 for large text)
  contrast: {
    // Minimum ratios
    minimumNormalText: 7.0, // AAA
    minimumLargeText: 4.5, // AA (18pt+ or 14pt+ bold)
    minimumGraphics: 3.0, // AA for UI components

    // Pre-validated high contrast pairs
    validPairs: [
      { text: colors.text.primary, background: colors.background.primary, ratio: 16.5 },
      { text: colors.text.primary, background: colors.neutral[500], ratio: 12.8 },
      { text: colors.text.inverse, background: colors.primary[600], ratio: 8.2 },
      { text: colors.text.inverse, background: colors.secondary[600], ratio: 7.8 },
      { text: colors.success[500], background: colors.background.primary, ratio: 7.5 },
      { text: colors.error[500], background: colors.background.primary, ratio: 7.2 },
      { text: colors.warning[500], background: colors.background.primary, ratio: 7.1 },
      { text: colors.info[500], background: colors.background.primary, ratio: 7.3 },
    ],
  },

  // Touch and click targets (WCAG 2.5.5 Level AAA)
  touchTarget: {
    // Minimum sizes
    minimum: "44px", // WCAG AAA requirement
    recommended: "48px", // Better for elderly users
    large: "56px", // Extra large for primary actions

    // Spacing between targets
    minSpacing: "8px",
    recommendedSpacing: "16px",

    // Hit area expansion (for small visual elements)
    hitAreaPadding: "12px",
  },

  // Motion and animation preferences
  motion: {
    // Reduced motion preferences (WCAG 2.3.3 Level AAA)
    prefersReduced: {
      duration: "0.01ms", // Near instant
      timingFunction: "linear",
      transitionProperty: "color, background-color, border-color",
    },

    // Normal motion (elder-friendly - slower than default)
    normal: {
      durationFast: "200ms",
      durationNormal: "400ms", // Slower than typical 300ms
      durationSlow: "600ms",
      timingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    },

    // Page transitions
    pageTransition: {
      duration: "500ms",
      timingFunction: "ease-in-out",
    },
  },

  // Screen reader utilities
  screenReader: {
    // Visually hidden but accessible to screen readers
    srOnly: {
      position: "absolute",
      width: "1px",
      height: "1px",
      padding: "0",
      margin: "-1px",
      overflow: "hidden",
      clip: "rect(0, 0, 0, 0)",
      whiteSpace: "nowrap",
      borderWidth: "0",
    },

    // Skip navigation link
    skipLink: {
      position: "absolute",
      left: "-9999px",
      zIndex: "9999",
      padding: "1rem",
      backgroundColor: colors.primary[500],
      color: colors.text.inverse,
      textDecoration: "none",
      // Visible on focus
      focusPosition: "fixed",
      focusTop: "1rem",
      focusLeft: "1rem",
    },
  },

  // Text sizing and spacing (WCAG 1.4.12 Level AA)
  textSpacing: {
    // Users should be able to adjust these without breaking layout
    lineHeight: "1.5", // Minimum
    paragraphSpacing: "2em", // Minimum
    letterSpacing: "0.12em", // Maximum user adjustment
    wordSpacing: "0.16em", // Maximum user adjustment
  },

  // High contrast mode support
  highContrast: {
    enabled: false, // Default off, can be toggled
    colors: {
      text: "#000000",
      background: "#ffffff",
      link: "#0000ff",
      linkVisited: "#551a8b",
      linkActive: "#ff0000",
      border: "#000000",
      focusRing: "#000000",
    },
  },

  // Keyboard navigation
  keyboard: {
    // Tab order visualization
    tabIndexDefault: 0,
    tabIndexRemove: -1,

    // Keyboard shortcuts (avoid conflicts with screen readers)
    shortcutsEnabled: true,
    shortcutModifier: "Alt", // Use Alt+ to avoid conflicts

    // Focus trap for modals
    focusTrap: true,
  },

  // ARIA attributes
  aria: {
    // Live region politeness
    liveRegionPolite: "polite",
    liveRegionAssertive: "assertive",

    // Common roles
    roles: {
      navigation: "navigation",
      main: "main",
      complementary: "complementary",
      contentinfo: "contentinfo",
      banner: "banner",
      search: "search",
      form: "form",
      alert: "alert",
      dialog: "dialog",
    },
  },

  // Elder-friendly specific enhancements
  elderFriendly: {
    // Larger interactive elements
    buttonMinHeight: "56px",
    inputMinHeight: "52px",
    checkboxSize: "28px",
    radioSize: "28px",

    // Enhanced focus indicators
    enhancedFocusRingWidth: "4px",
    enhancedFocusRingColor: colors.primary[600],

    // Loading states (visible, not anxiety-inducing)
    loadingTimeout: "800ms", // Show loading after 800ms
    loadingMinDuration: "400ms", // Keep loading visible for at least 400ms

    // Error prevention
    confirmDestructiveActions: true,
    doubleClickPrevention: true,
    debounceDelay: "500ms",
  },
} as const;

/**
 * Accessibility utilities
 */
export const a11yUtils = {
  // Generate ARIA labels
  generateAriaLabel: (label: string, context?: string): string => {
    return context ? `${label} - ${context}` : label;
  },

  // Check if motion should be reduced
  shouldReduceMotion: (): boolean => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  },

  // Check if high contrast is preferred
  prefersHighContrast: (): boolean => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(prefers-contrast: high)").matches;
  },

  // Focus management
  trapFocus: (element: HTMLElement): (() => void) => {
    const focusableElements = element.querySelectorAll(
      'a[href], button, textarea, input, select, [tabindex]:not([tabindex="-1"])'
    );
    const firstElement = focusableElements[0] as HTMLElement;
    const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

    const handleTab = (e: KeyboardEvent) => {
      if (e.key !== "Tab") return;

      if (e.shiftKey && document.activeElement === firstElement) {
        e.preventDefault();
        lastElement.focus();
      } else if (!e.shiftKey && document.activeElement === lastElement) {
        e.preventDefault();
        firstElement.focus();
      }
    };

    element.addEventListener("keydown", handleTab);
    return () => element.removeEventListener("keydown", handleTab);
  },
} as const;

export type Accessibility = typeof accessibility;
export type A11yUtils = typeof a11yUtils;
