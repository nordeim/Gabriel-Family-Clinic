/**
 * Typography System for Gabriel Family Clinic
 * Elder-friendly, highly readable typography with 18px base size
 */

export const typography = {
  // Font Families
  fontFamily: {
    // Headings - Modern Poppins for Clean Authority
    display: ["Poppins", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"].join(", "),
    
    // Body - Clean Inter for Readability  
    sans: [
      "Inter",
      "-apple-system",
      "BlinkMacSystemFont", 
      "Segoe UI",
      "Roboto",
      "Helvetica Neue",
      "Arial",
      "sans-serif",
    ].join(", "),
    
    // Special - Inter for UI consistency
    rounded: ["Inter", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"].join(", "),
    
    // Traditional serif fallback
    serif: ["Georgia", "Cambria", "Times New Roman", "Times", "serif"].join(", "),
    
    // Monospace for code
    mono: [
      "ui-monospace",
      "SFMono-Regular",
      "Menlo",
      "Monaco", 
      "Consolas",
      "Liberation Mono",
      "Courier New",
      "monospace",
    ].join(", "),
  },

  // Font Sizes - Elder-friendly with 18px base
  fontSize: {
    xs: {
      size: "0.75rem", // 12px - Use sparingly
      lineHeight: "1rem", // 16px
      letterSpacing: "0.01em",
    },
    sm: {
      size: "0.875rem", // 14px - Minimum recommended
      lineHeight: "1.25rem", // 20px
      letterSpacing: "0.01em",
    },
    base: {
      size: "1.125rem", // 18px - Elder-friendly base
      lineHeight: "1.75rem", // 28px
      letterSpacing: "0",
    },
    lg: {
      size: "1.25rem", // 20px
      lineHeight: "1.875rem", // 30px
      letterSpacing: "-0.01em",
    },
    xl: {
      size: "1.5rem", // 24px
      lineHeight: "2rem", // 32px
      letterSpacing: "-0.01em",
    },
    "2xl": {
      size: "1.875rem", // 30px
      lineHeight: "2.5rem", // 40px
      letterSpacing: "-0.02em",
    },
    "3xl": {
      size: "2.25rem", // 36px
      lineHeight: "2.75rem", // 44px
      letterSpacing: "-0.02em",
    },
    "4xl": {
      size: "3rem", // 48px
      lineHeight: "3.5rem", // 56px
      letterSpacing: "-0.03em",
    },
    "5xl": {
      size: "3.75rem", // 60px
      lineHeight: "4.25rem", // 68px
      letterSpacing: "-0.03em",
    },
    "6xl": {
      size: "4.5rem", // 72px
      lineHeight: "5rem", // 80px
      letterSpacing: "-0.04em",
    },
  },

  // Font Weights
  fontWeight: {
    light: "300",
    normal: "400",
    medium: "500",
    semibold: "600",
    bold: "700",
    extrabold: "800",
  },

  // Line Heights - Generous for readability
  lineHeight: {
    none: "1",
    tight: "1.25",
    snug: "1.375",
    normal: "1.5",
    relaxed: "1.75", // Recommended for body text
    loose: "2",
    extra: "2.5",
  },

  // Letter Spacing
  letterSpacing: {
    tighter: "-0.04em",
    tight: "-0.02em",
    normal: "0",
    wide: "0.01em",
    wider: "0.02em",
    widest: "0.04em",
  },

  // Text Styles - Pre-configured combinations
  textStyles: {
    // Headings - Modern Poppins for Professional Authority
    h1: {
      fontSize: "clamp(2.5rem, 5vw, 3.25rem)", // 40px -> 52px responsive
      lineHeight: "1.25", // 52px
      fontWeight: "600",
      letterSpacing: "-0.02em",
      fontFamily: "display",
    },
    h2: {
      fontSize: "clamp(2rem, 4vw, 2.5rem)", // 32px -> 40px responsive
      lineHeight: "1.25", // 50px
      fontWeight: "600",
      letterSpacing: "-0.02em",
      fontFamily: "display",
    },
    h3: {
      fontSize: "clamp(1.75rem, 3vw, 2.25rem)", // 28px -> 36px responsive
      lineHeight: "1.25", // 45px
      fontWeight: "600",
      letterSpacing: "-0.01em",
      fontFamily: "display",
    },
    h4: {
      fontSize: "1.875rem", // 30px
      lineHeight: "1.25", // 37.5px
      fontWeight: "600",
      letterSpacing: "-0.01em",
      fontFamily: "display",
    },
    h5: {
      fontSize: "1.5rem", // 24px
      lineHeight: "1.25", // 30px
      fontWeight: "600",
      letterSpacing: "-0.01em",
      fontFamily: "display",
    },
    h6: {
      fontSize: "1.25rem", // 20px
      lineHeight: "1.25", // 25px
      fontWeight: "600",
      letterSpacing: "-0.01em",
      fontFamily: "display",
    },

    // Body Text
    bodyLarge: {
      fontSize: "1.25rem", // 20px
      lineHeight: "1.875rem", // 30px
      fontWeight: "400",
      letterSpacing: "0",
      fontFamily: "sans",
    },
    body: {
      fontSize: "1.125rem", // 18px (base)
      lineHeight: "1.75rem", // 28px
      fontWeight: "400",
      letterSpacing: "0",
      fontFamily: "sans",
    },
    bodySmall: {
      fontSize: "0.875rem", // 14px
      lineHeight: "1.25rem", // 20px
      fontWeight: "400",
      letterSpacing: "0.01em",
      fontFamily: "sans",
    },

    // UI Elements - Friendly rounded font
    button: {
      fontSize: "1.125rem", // 18px
      lineHeight: "1.75rem", // 28px
      fontWeight: "600",
      letterSpacing: "0.01em",
      fontFamily: "rounded",
    },
    buttonLarge: {
      fontSize: "1.25rem", // 20px
      lineHeight: "1.875rem", // 30px
      fontWeight: "600",
      letterSpacing: "0",
      fontFamily: "rounded",
    },
    label: {
      fontSize: "0.875rem", // 14px
      lineHeight: "1.25rem", // 20px
      fontWeight: "500",
      letterSpacing: "0.01em",
      fontFamily: "sans",
    },
    caption: {
      fontSize: "0.875rem", // 14px
      lineHeight: "1.25rem", // 20px
      fontWeight: "400",
      letterSpacing: "0.01em",
      fontFamily: "sans",
    },
  },
} as const;

/**
 * Typography utilities for elder-friendly reading
 */
export const typographyUtils = {
  // Recommended minimum sizes for different content types
  minimumSizes: {
    bodyText: "1.125rem", // 18px
    buttonText: "1rem", // 16px
    labelText: "0.875rem", // 14px
    headingText: "1.5rem", // 24px
  },

  // Accessibility guidelines
  accessibility: {
    // Text should be resizable up to 200% without loss of functionality
    maxScale: 2,
    // Minimum line height for body text
    minLineHeight: 1.5,
    // Recommended line length for optimal readability
    optimalLineLength: "65ch",
    maxLineLength: "75ch",
  },

  // Elder-friendly recommendations
  elderFriendly: {
    baseFontSize: "1.125rem", // 18px
    minTouchTarget: "44px",
    recommendedLineHeight: 1.75,
    recommendedLetterSpacing: "0",
    avoidSmallCaps: true, // Small caps reduce readability
    avoidItalics: "minimize", // Italics can be harder to read
  },
} as const;

export type Typography = typeof typography;
export type TextStyle = keyof typeof typography.textStyles;
